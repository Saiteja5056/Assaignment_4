create table student(student_id int primary key ,sname varchar(30),qualififation varchar(30),skils varchar(30))

create table company(company_id int primary key ,name varchar(30),Address varchar(30),city varchar(30))
insert into student values (1,'sai','B,tech','Java')
insert into company values (1,'Tcs','Hyderabad','Telangana')
