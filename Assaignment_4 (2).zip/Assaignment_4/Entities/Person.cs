﻿using System;
using System.Collections.Generic;

namespace Assaignment_4.Entities;

public partial class Person
{
    public int? Pid { get; set; }

    public string? Pname { get; set; }
}
