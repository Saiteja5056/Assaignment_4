﻿using System;
using System.Collections.Generic;

namespace Assaignment_4.Entities;

public partial class Employee
{
    public int EmployeeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Designation { get; set; }

    public DateOnly? JoinDate { get; set; }

    public decimal? Salary { get; set; }
}
