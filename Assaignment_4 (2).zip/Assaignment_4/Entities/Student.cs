﻿using System;
using System.Collections.Generic;

namespace Assaignment_4.Entities;

public partial class Student
{
    public int StudentId { get; set; }

    public string? Sname { get; set; }

    public string? Qualififation { get; set; }

    public string? Skils { get; set; }
}
