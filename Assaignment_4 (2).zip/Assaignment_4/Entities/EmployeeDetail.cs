﻿using System;
using System.Collections.Generic;

namespace Assaignment_4.Entities;

public partial class EmployeeDetail
{
    public int EmpId { get; set; }

    public string EmpName { get; set; } = null!;

    public string Designation { get; set; } = null!;

    public DateOnly JoinDate { get; set; }

    public string? DeptCode { get; set; }

    public virtual Department? DeptCodeNavigation { get; set; }
}
