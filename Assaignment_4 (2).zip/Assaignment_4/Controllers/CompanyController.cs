﻿using Assaignment_4.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assaignment_4.Controllers
{

    public class CompanyController : Controller
    {
        private readonly BookDetailsContext bookDetailsContext;
        public CompanyController()
        {
            bookDetailsContext = new BookDetailsContext();
        }
        public IActionResult Index()
        {
            var companies = bookDetailsContext.Companies;
            return View(companies);
        }
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Create(Company company)
        {
            if (ModelState.IsValid)
            {
                bookDetailsContext.Companies.Add(company);
                bookDetailsContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
           
        }
    }
}

