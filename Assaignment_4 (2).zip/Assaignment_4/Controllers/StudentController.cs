﻿using Assaignment_4.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assaignment_4.Controllers
{
    public class StudentController : Controller
    {
        private readonly BookDetailsContext bookDetailsContext;
        public StudentController()
        {
            bookDetailsContext = new BookDetailsContext();
        }
        public IActionResult Index()
        {
            var students = bookDetailsContext.Students;
            return View(students);
        }
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                bookDetailsContext.Students.Add(student);
                bookDetailsContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
        }

        public IActionResult Delete(int id)
        {
            var student = bookDetailsContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {

            bookDetailsContext.Students.Remove(student);
            bookDetailsContext.SaveChanges();
            return RedirectToAction("Index");

        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var student = bookDetailsContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Edit(Student student)
        {
            if (ModelState.IsValid)
            {
                bookDetailsContext.Students.Update(student);
                bookDetailsContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
        }

        public IActionResult Details(int id)
        {
            var student = bookDetailsContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
